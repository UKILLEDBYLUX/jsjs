package com.example.armortint.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.client.render.entity.equipment.EquipmentRenderer;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(EquipmentRenderer.class)
public abstract class EquipmentRendererMixin {

    @ModifyArg(
        method = "render",
        at = @At(value = "INVOKE",
                 target = "Lnet/minecraft/client/model/Model;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;III)V"),
        index = 4
    )
    private int tintDamaged(int color, @Local(argsOnly = true) ItemStack stack) {
        if (!stack.isDamageable()) return color;

        float left = 1f - (float) stack.getDamage() / stack.getMaxDamage();
        if (left > 0.10f) return color; // порог 10%

        int a = (color >> 24) & 0xFF;
        int r = (color >> 16) & 0xFF;
        int g = ((color >> 8) & 0xFF) / 4;
        int b = (color & 0xFF) / 4;
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
